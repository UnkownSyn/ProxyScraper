# Lunus Best Proxy Scraper 🪐
Lunus BPS is a tool to obtain proxies and verify if they are valid in real-time. We have added support for HTTP/s, SOCKS4, and SOCKS5. When verifying the proxies, your computer might slow down a bit due to the threads.

## 📹 Preview

https://github.com/H4cK3dR4Du/Discord-Member-Booster/assets/118562174/3a50780a-e265-49b5-bf11-f626f921b2fd

## 🔥 Features
- Proxy Scraper
- Proxy Checker
- Around +150K Proxies
- Fast & Slick UI
- Easy To Setup
- Fully Requests Based
- HTTP/s, SOCKS4 & SOCKS5 Scraper/Checker

## ⚠️ DISCLAIMER / NOTES
This github repo is for EDUCATIONAL PURPOSES ONLY. We Are NOT under any responsibility if a problem occurs.

## ✨ Issues / Doubts

- If you have any questions do not hesitate to enter my discord: https://discord.gg/raducord
- Or if you have any error do not forget to report it in: [issues](https://github.com/H4cK3dR4Du/LunusBPS/issues/new)
